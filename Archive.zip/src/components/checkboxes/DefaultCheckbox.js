import React from "react";
import "./_checkboxes.scss";

function DefaultCheckbox(props) {
  return (
    <div>
      <input type="checkbox" id={`checkbox${props.children}`}></input>
      <label htmlFor={`checkbox${props.children}`}>{props.children}</label>
    </div>
  );
}

export default DefaultCheckbox;

import React from "react";
import "./_buttons.scss";

let RectangularButton = (props) => {
  return <div className="rect"> {props.children} </div>;
};

export default RectangularButton;

import React from "react";
import "./_buttons.scss";

let RectangularButton = () => {
  return <div className="rect"> </div>;
};

export default RectangularButton;

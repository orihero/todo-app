import React from "react";

function CircleButton(props) {
  return <div className="circle"></div>;
}

export default CircleButton;

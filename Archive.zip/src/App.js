import "./App.css";
import "./assets/styles/_index.scss";
import CircleButton from "./components/buttons/CircleButton";
import RectangularButton from "./components/buttons/RectangularButton";

function App() {
  return (
    <div className="wrapper">
      <div className="card">
        <RectangularButton />
        <CircleButton />
      </div>
    </div>
  );
}

export default App;
